//
//  MyAdventureApp.swift
//  MyAdventure
//
//  Created by user937495 on 6/26/24.
//

import SwiftUI

@main
struct MyAdventureApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
